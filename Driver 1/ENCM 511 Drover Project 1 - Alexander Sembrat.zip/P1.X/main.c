/* 
 * File:   main.c
 * Author: Alexander Sembrat
 * ENCM 511 Driver Project 1
 *
 * Created on September 13, 2021, 12:11 PM
 */

#include <xc.h>

/*
 * 
 */
int main() {
    TRISAbits.TRISA0 = 1;   //Sets RA0-GPIO2 as input
    TRISAbits.TRISA1 = 1;   //Sets RA1-GPIO3 as input
    TRISAbits.TRISA2 = 1;   //Sets RA2-GPIO7 as input
    TRISAbits.TRISA4 = 1;   //Sets RA4-GPIO10 as input
   
    TRISBbits.TRISB0 = 0;   //Sets RB0-GPIO4 as output
    TRISBbits.TRISB1 = 0;   //Sets RB1-GPIO5 as output
    TRISBbits.TRISB2 = 0;   //Sets RB2-GPIO6 as output
    TRISBbits.TRISB4 = 0;   //Sets RB4-GPIO9 as output
    TRISBbits.TRISB7 = 0;   //Sets RB7-GPIO11 as output
    TRISBbits.TRISB8 = 0;   //Sets RB8-GPIO12 as output
    TRISBbits.TRISB9 = 0;   //Sets RB9-GPIO13 as output
    TRISBbits.TRISB12 = 0;  //Sets RB12-GPIO15 as output
    TRISBbits.TRISB13 = 0;  //Sets RB13-GPIO16 as output
    
    while(1){
        
        if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 1)){ //if input = 0001 turn 3 LED's ON
            LATBbits.LATB0 = 1;     //Sets RBO to hi
            LATBbits.LATB1 = 1;     //Sets RB1 to hi
            LATBbits.LATB2 = 1;     //Sets RB2 to hi
            LATBbits.LATB4 = 0;     //Sets RB4 to lo
            LATBbits.LATB7 = 0;     //Sets RB7 to lo
            LATBbits.LATB8 = 0;     //Sets RB8 to lo
            LATBbits.LATB9 = 0;     //Sets RB9 to lo
            LATBbits.LATB12 = 0;    //Sets RB12 to lo
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
        }
        else if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 0)){ //if input = 0010 turn 0 LED's ON
            LATBbits.LATB0 = 0;     //Sets RBO to lo
            LATBbits.LATB1 = 0;     //Sets RB1 to lo
            LATBbits.LATB2 = 0;     //Sets RB2 to lo
            LATBbits.LATB4 = 0;     //Sets RB4 to lo
            LATBbits.LATB7 = 0;     //Sets RB7 to lo
            LATBbits.LATB8 = 0;     //Sets RB8 to lo
            LATBbits.LATB9 = 0;     //Sets RB9 to lo
            LATBbits.LATB12 = 0;    //Sets RB12 to lo
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
        }
        else if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 1)){ //if input = 0011 turn 0 LED's ON
            LATBbits.LATB0 = 0;     //Sets RBO to lo
            LATBbits.LATB1 = 0;     //Sets RB1 to lo
            LATBbits.LATB2 = 0;     //Sets RB2 to lo
            LATBbits.LATB4 = 0;     //Sets RB4 to lo
            LATBbits.LATB7 = 0;     //Sets RB7 to lo
            LATBbits.LATB8 = 0;     //Sets RB8 to lo
            LATBbits.LATB9 = 0;     //Sets RB9 to lo
            LATBbits.LATB12 = 0;    //Sets RB12 to lo
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
        }
        else if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 0)){ //if input = 0100 turn 8 LED's ON
            LATBbits.LATB0 = 1;     //Sets RBO to hi
            LATBbits.LATB1 = 1;     //Sets RB1 to hi
            LATBbits.LATB2 = 1;     //Sets RB2 to hi
            LATBbits.LATB4 = 1;     //Sets RB4 to hi
            LATBbits.LATB7 = 1;     //Sets RB7 to hi
            LATBbits.LATB8 = 1;     //Sets RB8 to hi
            LATBbits.LATB9 = 1;     //Sets RB9 to hi
            LATBbits.LATB12 = 1;    //Sets RB12 to hi
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
        }
        else if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 1)){ //if input = 0101 turn 9 LED's ON
            LATBbits.LATB0 = 1;     //Sets RBO to hi
            LATBbits.LATB1 = 1;     //Sets RB1 to hi
            LATBbits.LATB2 = 1;     //Sets RB2 to hi
            LATBbits.LATB4 = 1;     //Sets RB4 to hi
            LATBbits.LATB7 = 1;     //Sets RB7 to hi
            LATBbits.LATB8 = 1;     //Sets RB8 to hi
            LATBbits.LATB9 = 1;     //Sets RB9 to hi
            LATBbits.LATB12 = 1;    //Sets RB12 to hi
            LATBbits.LATB13 = 1;    //Sets RB13 to hi            
        }
        else if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 0)){ //if input = 0110 turn 1 LED ON
            LATBbits.LATB0 = 1;     //Sets RBO to hi
            LATBbits.LATB1 = 0;     //Sets RB1 to lo
            LATBbits.LATB2 = 0;     //Sets RB2 to lo
            LATBbits.LATB4 = 0;     //Sets RB4 to lo
            LATBbits.LATB7 = 0;     //Sets RB7 to lo
            LATBbits.LATB8 = 0;     //Sets RB8 to lo
            LATBbits.LATB9 = 0;     //Sets RB9 to lo
            LATBbits.LATB12 = 0;    //Sets RB12 to lo
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
            
        }
        else if((PORTAbits.RA0 == 0) && (PORTAbits.RA1 == 1) && (PORTAbits.RA2 == 1) && (PORTAbits.RA4 == 1)){ //if input = 0111 turn 8 LED's ON
            LATBbits.LATB0 = 1;     //Sets RBO to hi
            LATBbits.LATB1 = 1;     //Sets RB1 to hi
            LATBbits.LATB2 = 1;     //Sets RB2 to hi
            LATBbits.LATB4 = 1;     //Sets RB4 to hi
            LATBbits.LATB7 = 1;     //Sets RB7 to hi
            LATBbits.LATB8 = 1;     //Sets RB8 to hi
            LATBbits.LATB9 = 1;     //Sets RB9 to hi
            LATBbits.LATB12 = 1;    //Sets RB12 to hi
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
            
        }
        else if((PORTAbits.RA0 == 1) && (PORTAbits.RA1 == 0) && (PORTAbits.RA2 == 0) && (PORTAbits.RA4 == 0)){ //if input = 1000 turn 8 LED's ON
            LATBbits.LATB0 = 1;     //Sets RBO to hi
            LATBbits.LATB1 = 1;     //Sets RB1 to hi
            LATBbits.LATB2 = 1;     //Sets RB2 to hi
            LATBbits.LATB4 = 1;     //Sets RB4 to hi
            LATBbits.LATB7 = 1;     //Sets RB7 to hi
            LATBbits.LATB8 = 1;     //Sets RB8 to hi
            LATBbits.LATB9 = 1;     //Sets RB9 to hi
            LATBbits.LATB12 = 1;    //Sets RB12 to hi
            LATBbits.LATB13 = 0;    //Sets RB13 to lo 
            
        }
        else{ //for any other input turn 0 LED's ON
            LATBbits.LATB0 = 0;     //Sets RBO to lo
            LATBbits.LATB1 = 0;     //Sets RB1 to lo
            LATBbits.LATB2 = 0;     //Sets RB2 to lo
            LATBbits.LATB4 = 0;     //Sets RB4 to lo
            LATBbits.LATB7 = 0;     //Sets RB7 to lo
            LATBbits.LATB8 = 0;     //Sets RB8 to lo
            LATBbits.LATB9 = 0;     //Sets RB9 to lo
            LATBbits.LATB12 = 0;    //Sets RB12 to lo
            LATBbits.LATB13 = 0;    //Sets RB13 to lo
        }
        
    }
    return 0;
}

